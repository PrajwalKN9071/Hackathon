import openai
from app.config import AzureConfig

class AzureOpenAIService:
    def __init__(self):
        # Set Azure API details
        openai.api_key = AzureConfig.OPENAI_API_KEY
        openai.api_base = AzureConfig.OPENAI_ENDPOINT
        openai.api_version = AzureConfig.OPENAI_API_VERSION 
        self.deployment = AzureConfig.OPENAI_DEPLOYMENT  # For example: "gpt-4" or "gpt-3.5-turbo"

    def get_chatbot_response(self, prompt: str):
        try:
            # Use openai.Completion.create for Azure OpenAI Standard models
            response = openai.Completion.create(
                model=self.deployment,  # Example: "gpt-3.5-turbo" or "gpt-4"
                prompt=prompt,
                max_tokens=150,  # Limit response length
                temperature=0.7  # Control randomness of response
            )
            return response['choices'][0]['text'].strip()
        except Exception as e:
            return f"Error: {str(e)}"
