class AzureConfig:
    OPENAI_API_KEY = "93SDGcu0xnmSUvCltniv927b42tacvG4J86Xqhg0cv1LC1GC5yTuJQQJ99AKACYeBjFXJ3w3AAABACOGfkZd"  # Your Azure OpenAI API key
    OPENAI_ENDPOINT = "https://tripplanning9071.openai.azure.com/"  # Example: https://your-resource-name.openai.azure.com/
    OPENAI_DEPLOYMENT = "gpt-3.5-turbo"  # Example: "gpt-3.5-turbo" or "gpt-4"
    OPENAI_API_VERSION = "2023-05-15" 
