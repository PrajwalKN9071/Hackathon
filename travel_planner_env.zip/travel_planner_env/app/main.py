from fastapi import FastAPI
from app.routers import chatbot

app = FastAPI(title="Travel Planner API", version="1.0.0")

# Include router for chatbot-related endpoints
app.include_router(chatbot.router)

@app.get("/")
def read_root():
    return {"message": "Welcome to the Travel Planner API!"}