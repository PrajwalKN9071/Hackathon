from fastapi import APIRouter, HTTPException
from app.services.azure_openai import AzureOpenAIService

router = APIRouter(
    prefix="/chatbot",
    tags=["Chatbot"]
)

ai_service = AzureOpenAIService()

@router.post("/ask")
def ask_chatbot(question: str):
    response = ai_service.get_chatbot_response(question)
    if "Error" in response:
        raise HTTPException(status_code=500, detail=response)
    return {"response": response}
